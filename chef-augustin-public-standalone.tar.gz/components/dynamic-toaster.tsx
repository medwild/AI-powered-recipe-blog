"use client"

import dynamic from "next/dynamic"

const Toaster = dynamic(
  () => import("@/components/ui/sonner").then((m) => m.Toaster),
  { ssr: false },
)

export function DynamicToaster() {
  return <Toaster position="top-center" richColors />
}
